# � Rhinometric Trial - Instalación en Linux

## ✅ Requisitos Previos

- Linux: Ubuntu 20.04+, Debian 11+, RHEL 8+, Fedora 35+, etc.
- 8 GB RAM mínimo (16 GB recomendado)
- 50 GB espacio en disco
- Docker y Docker Compose v2+ instalados

### Instalar Docker (si no lo tienes)

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install -y docker.io docker-compose-plugin
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER
newgrp docker
```

**RHEL/CentOS/Fedora:**
```bash
sudo dnf install -y docker docker-compose-plugin
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER
newgrp docker
```

**Verificar instalación:**
```bash
docker --version
docker compose version
```

---

## 📦 Instalación Rhinometric

### Paso 1: Extraer el ZIP

```bash
# Crear directorio
mkdir -p ~/rhinometric-trial

# Extraer
unzip rhinometric-trial-v1.0.0-production.zip -d ~/rhinometric-trial

# Navegar
cd ~/rhinometric-trial/rhinometric-trial-v1.0.0-production
```

### Paso 2: Verificar archivos

```bash
ls -la
```

**Deberías ver:**
- `docker-compose.yml`
- `.env`
- `config/`
- `grafana/`
- `licensing/`
- `license-dashboard/`
- `init-db/`
- `start.sh`, `stop.sh`, `validate.sh`
- Guías: `README.md`, `INSTALACION_*.md`

### Paso 3: Iniciar Rhinometric

```bash
docker compose up -d
```

**Salida esperada:**
```
[+] Running 16/16
 ✔ Container rhinometric-postgres           Started
 ✔ Container rhinometric-redis              Started
 ✔ Container rhinometric-license-server     Started
 ✔ Container rhinometric-prometheus         Started
 ✔ Container rhinometric-loki               Started
 ✔ Container rhinometric-tempo              Started
 ✔ Container rhinometric-telemetrygen       Started
 ✔ Container rhinometric-grafana            Started
 ✔ Container rhinometric-alertmanager       Started
 ✔ Container rhinometric-node-exporter      Started
 ✔ Container rhinometric-cadvisor           Started
 ✔ Container rhinometric-blackbox-exporter  Started
 ✔ Container rhinometric-postgres-exporter  Started
 ✔ Container rhinometric-license-dashboard  Started
 ✔ Container rhinometric-nginx              Started
 ✔ Container rhinometric-promtail           Started
```

⏳ **Espera 30-60 segundos** para que todos los servicios estén listos.

### Paso 4: Verificar Instalación

```bash
docker ps | grep rhinometric
```

Deberías ver 16 contenedores con estado **"Up"**.

**Alternativa:** Script de validación:
```bash
chmod +x validate.sh
./validate.sh
```

### Paso 5: Abrir Grafana

**Desde el mismo servidor:**
```bash
curl http://localhost:3000
```

**Desde tu navegador local:**
1. Abre Chrome, Firefox, etc.
2. Ve a: **http://localhost:3000** (o IP del servidor si es remoto)
3. Login:
   - **Usuario:** `admin`
   - **Contraseña:** `admin_secure_2024`

🎉 **¡Listo!** Explora los 7 dashboards precargados.

---

## 🛑 Detener Rhinometric

```bash
docker compose down
```

---

## 🔄 Reiniciar Rhinometric

```bash
docker compose restart
```

---

## 🔧 Troubleshooting

### ❌ Error "permission denied" (Docker socket)

**Solución:**
```bash
# Agregar tu usuario al grupo docker
sudo usermod -aG docker $USER
newgrp docker

# Verificar
docker ps
```

### ❌ Error "port 3000 is already allocated"

**Solución:**
```bash
# Ver qué proceso usa el puerto
sudo lsof -i :3000

# O:
sudo netstat -tulpn | grep :3000

# Detener el proceso:
sudo kill -9 <PID>
```

### ❌ Error "Cannot connect to Docker daemon"

**Solución:**
```bash
# Iniciar Docker
sudo systemctl start docker

# Habilitar auto-start
sudo systemctl enable docker

# Verificar estado
sudo systemctl status docker
```

### ❌ RAM insuficiente

**Solución:**
```bash
# Ver memoria disponible
free -h

# Si tienes menos de 8GB, cerrar otros servicios
sudo systemctl stop <servicio-innecesario>
```

### ❌ Firewall bloqueando puertos

**Solución en Ubuntu/Debian:**
```bash
# Permitir puerto 3000
sudo ufw allow 3000/tcp

# Verificar reglas
sudo ufw status
```

**Solución en RHEL/Fedora:**
```bash
# Permitir puerto 3000
sudo firewall-cmd --add-port=3000/tcp --permanent
sudo firewall-cmd --reload
```

---

## 📊 Comandos Útiles

```bash
# Ver logs de un contenedor
docker logs rhinometric-grafana

# Ver logs en tiempo real
docker logs -f rhinometric-prometheus

# Ver uso de recursos
docker stats

# Reiniciar un contenedor específico
docker restart rhinometric-loki

# Eliminar volúmenes (CUIDADO: borra todos los datos)
docker compose down -v
```

---

## 📞 Soporte

Si los problemas persisten:

```bash
# Guardar logs completos
docker compose logs > rhinometric-logs.txt

# Información del sistema
uname -a > system-info.txt
docker --version >> system-info.txt
docker compose version >> system-info.txt
free -h >> system-info.txt
```

Envía ambos archivos a: support@rhinometric.com

---

**Versión:** 1.0.0-production | **OS:** Linux (Ubuntu/Debian/RHEL/Fedora)
