# 🍎 Rhinometric Trial - Instalación en macOS

## ✅ Requisitos Previos

- macOS 11 Big Sur o superior
- 8 GB RAM mínimo (16 GB recomendado)
- 50 GB espacio en disco
- Docker Desktop para Mac instalado

**Compatibilidad:**
- ✅ Intel Macs (x86_64)
- ✅ Apple Silicon (M1/M2/M3 - ARM64)

### Instalar Docker Desktop

Si no tienes Docker Desktop:

1. Descargar de: https://www.docker.com/products/docker-desktop
2. Elegir versión:
   - **Intel Chip** para Macs con procesador Intel
   - **Apple Chip** para Macs con M1/M2/M3
3. Arrastrar Docker.app a Aplicaciones
4. Abrir Docker desde Aplicaciones
5. Esperar a que el ícono en la barra de menú diga "Docker Desktop is running"

---

## 📦 Instalación Rhinometric

### Paso 1: Extraer el ZIP

**Opción A: Interfaz gráfica**
1. Doble clic en `rhinometric-trial-v1.0.0-production.zip`
2. Se extrae automáticamente en la misma carpeta
3. Mover carpeta a `~/rhinometric-trial`

**Opción B: Terminal**
```bash
mkdir -p ~/rhinometric-trial
unzip rhinometric-trial-v1.0.0-production.zip -d ~/rhinometric-trial
cd ~/rhinometric-trial/rhinometric-trial-v1.0.0-production
```

### Paso 2: Verificar Docker

```bash
docker --version
docker compose version
```

Si ves las versiones, Docker está listo. Si no:
1. Abrir Docker Desktop desde Aplicaciones
2. Esperar a que arranque
3. Verificar ícono en barra de menú superior

### Paso 3: Iniciar Rhinometric

```bash
cd ~/rhinometric-trial/rhinometric-trial-v1.0.0-production
docker compose up -d
```

**Salida esperada:**
```
[+] Running 16/16
 ✔ Container rhinometric-postgres           Started
 ✔ Container rhinometric-redis              Started
 ✔ Container rhinometric-license-server     Started
 ✔ Container rhinometric-prometheus         Started
 ✔ Container rhinometric-loki               Started
 ✔ Container rhinometric-tempo              Started
 ✔ Container rhinometric-telemetrygen       Started
 ✔ Container rhinometric-grafana            Started
 ✔ Container rhinometric-alertmanager       Started
 ✔ Container rhinometric-node-exporter      Started
 ✔ Container rhinometric-cadvisor           Started
 ✔ Container rhinometric-blackbox-exporter  Started
 ✔ Container rhinometric-postgres-exporter  Started
 ✔ Container rhinometric-license-dashboard  Started
 ✔ Container rhinometric-nginx              Started
 ✔ Container rhinometric-promtail           Started
```

⏳ **Espera 30-60 segundos** para que todos los servicios estén listos.

### Paso 4: Verificar Instalación

```bash
docker ps | grep rhinometric
```

Deberías ver 16 líneas (contenedores).

**Alternativa:** Script de validación:
```bash
./validate.sh
```

### Paso 5: Abrir Grafana

1. Abre Safari, Chrome o tu navegador preferido
2. Ve a: **http://localhost:3000**
3. Login:
   - **Usuario:** `admin`
   - **Contraseña:** `admin_secure_2024`

🎉 **¡Listo!** Explora los 7 dashboards precargados.

---

## 🛑 Detener Rhinometric

```bash
docker compose down
```

---

## 🔄 Reiniciar Rhinometric

```bash
docker compose restart
```

---

## 🔧 Troubleshooting

### ❌ Error "Docker daemon is not running"

**Solución:**
1. Abrir Docker Desktop desde Aplicaciones
2. Esperar a que el ícono muestre "Docker Desktop is running"
3. Reintentar

### ❌ Error "port 3000 is already allocated"

**Solución:**
```bash
# Ver qué proceso usa el puerto
lsof -i :3000

# Detener el proceso
kill -9 <PID>

# O cambiar el puerto en docker-compose.yml:
# grafana:
#   ports:
#     - "3001:3000"
```

### ❌ Error "permission denied" en /var/run/docker.sock

**Solución:**
```bash
# Agregar tu usuario al grupo docker
sudo usermod -aG docker $USER
newgrp docker

# O en macOS, verificar permisos en Docker Desktop:
# Settings → Advanced → Allow privileged port access
```

### ❌ Apple Silicon (M1/M2): Warning sobre arquitectura

**Solución:**
- Las imágenes son multi-arch (AMD64 + ARM64)
- Si ves warnings de "platform linux/amd64", ignóralos
- Docker en M1/M2 ejecuta mediante Rosetta 2

### ❌ RAM insuficiente

**Solución:**
1. Abrir Docker Desktop
2. Settings → Resources → Memory
3. Aumentar a mínimo **8 GB**
4. Clic "Apply & Restart"

---

## 📞 Soporte

Si los problemas persisten:

```bash
# Guardar logs
docker compose logs > rhinometric-logs.txt
```

Envía `rhinometric-logs.txt` a: support@rhinometric.com

---

**Versión:** 1.0.0-production | **OS:** macOS 11+
