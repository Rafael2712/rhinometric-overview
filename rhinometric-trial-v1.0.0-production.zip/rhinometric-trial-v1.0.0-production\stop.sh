#!/bin/bash
echo "🛑 Deteniendo Rhinometric Trial..."
docker compose down
echo "✅ Rhinometric Trial detenido"
