# 🦏 Rhinometric Trial v1.0.0-production

**Plataforma de Observabilidad Empresarial**

Logs + Métricas + Trazas Distribuidas | 16 Contenedores | 7 Dashboards | 30 días Trial

---

## 🚀 Instalación Rápida

### Windows
1. Extraer ZIP en `C:\rhinometric-trial`
2. Abrir PowerShell en la carpeta
3. `docker compose up -d`
4. Abrir http://localhost:3000

### macOS
1. Extraer ZIP en `~/rhinometric-trial`
2. Abrir Terminal
3. `cd ~/rhinometric-trial && docker compose up -d`
4. Abrir http://localhost:3000

### Linux
1. `unzip rhinometric-trial-v1.0.0-production.zip`
2. `cd rhinometric-trial-v1.0.0-production`
3. `docker compose up -d`
4. Abrir http://localhost:3000

---

## 🔐 Credenciales de Acceso

```
URL: http://localhost:3000
Usuario: admin
Contraseña: admin_secure_2024
```

*(Contraseña definida en archivo `.env`)*

---

## 📦 Contenido del Paquete

### 16 Contenedores
1. **rhinometric-grafana** - Dashboard principal
2. **rhinometric-prometheus** - Motor de métricas
3. **rhinometric-loki** - Agregador de logs
4. **rhinometric-tempo** - Distributed tracing
5. **rhinometric-postgres** - Base de datos
6. **rhinometric-redis** - Caché
7. **rhinometric-alertmanager** - Gestor de alertas
8. **rhinometric-nginx** - Reverse proxy
9. **rhinometric-promtail** - Agente de logs
10. **rhinometric-node-exporter** - Métricas del host
11. **rhinometric-cadvisor** - Métricas de contenedores
12. **rhinometric-blackbox-exporter** - Health checks
13. **rhinometric-postgres-exporter** - Métricas PostgreSQL
14. **rhinometric-telemetrygen** - Generador de trazas
15. **rhinometric-license-server** - Servidor de licencias
16. **rhinometric-license-dashboard** - Panel de licencias

### 7 Dashboards Precargados
1. **Overview** - Vista general del sistema
2. **Docker Containers** - Monitoreo de contenedores
3. **System Monitoring** - CPU, RAM, Disk, Network
4. **Logs Explorer** - Logs centralizados (Loki)
5. **Distributed Tracing** - Trazas distribuidas (Tempo)
6. **License Status** - Estado de licencias
7. **License Management** - Gestión de licencias

---

## ⚙️ Comandos Útiles

```bash
# Iniciar todo
docker compose up -d

# Ver estado
docker ps

# Ver logs de un servicio
docker logs rhinometric-grafana

# Ver logs en tiempo real
docker logs -f rhinometric-prometheus

# Reiniciar un servicio
docker restart rhinometric-loki

# Detener todo
docker compose down

# Validar instalación
./validate.sh
```

---

## 📊 Características

✅ **Métricas:** Prometheus scraping cada 15s, retención 7 días  
✅ **Logs:** Loki indexando todos los contenedores, LogQL queries  
✅ **Trazas:** Tempo capturando OTLP/Jaeger/Zipkin, 15 spans/seg  
✅ **Alertas:** 16 reglas preconfiguradas en Alertmanager  
✅ **License:** Time-Bomb de 30 días, hardware fingerprint  
✅ **Seguridad:** Autenticación JWT, contraseñas seguras

---

## 🔧 Troubleshooting

### ❌ Error "Docker no está corriendo"
```bash
# Windows/Mac: Abrir Docker Desktop
# Linux:
sudo systemctl start docker
```

### ❌ Error "Puerto 3000 ya está en uso"
```bash
# Ver qué proceso usa el puerto
# Windows:
netstat -ano | findstr :3000
# Mac/Linux:
lsof -i :3000

# Cambiar el puerto en docker-compose.yml:
# ports: - "3001:3000"
```

### ❌ Contenedores no inician
```bash
# Ver logs de error
docker logs rhinometric-grafana

# Verificar recursos
docker stats

# Reiniciar todo
docker compose down && docker compose up -d
```

---

## 📞 Soporte

- 📧 Email: support@rhinometric.com
- 📖 Docs: https://docs.rhinometric.com
- 💬 Comunidad: https://community.rhinometric.com

---

## 📝 Licencia

**Trial de 30 días** (Time-Bomb activado)

Para licencias comerciales: sales@rhinometric.com

---

**Rhinometric v1.0.0** © 2025 - Enterprise Observability Platform
