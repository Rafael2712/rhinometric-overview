# 🪟 Rhinometric Trial - Instalación en Windows 10/11

## ✅ Requisitos Previos

- Windows 10 (build 19041+) o Windows 11
- 8 GB RAM mínimo (16 GB recomendado)
- 50 GB espacio en disco
- Docker Desktop para Windows instalado

### Instalar Docker Desktop

Si no tienes Docker Desktop:

1. Descargar de: https://www.docker.com/products/docker-desktop
2. Ejecutar instalador
3. Reiniciar Windows
4. Abrir Docker Desktop
5. Esperar a que diga "Docker Desktop is running"

---

## 📦 Instalación Rhinometric

### Paso 1: Extraer el ZIP

1. Clic derecho en `rhinometric-trial-v1.0.0-production.zip`
2. Seleccionar **"Extraer todo..."**
3. Elegir ubicación: `C:\rhinometric-trial`
4. Clic **"Extraer"**

**Resultado:** Deberías tener `C:\rhinometric-trial\rhinometric-trial-v1.0.0-production\`

### Paso 2: Abrir PowerShell

1. Abre la carpeta `C:\rhinometric-trial\rhinometric-trial-v1.0.0-production`
2. En la barra de dirección del explorador, escribe: `powershell`
3. Presiona **Enter**

**Alternativa:**
- Shift + Clic derecho en espacio vacío
- Seleccionar "Abrir ventana de PowerShell aquí"

### Paso 3: Iniciar Rhinometric

En la ventana de PowerShell, ejecuta:

```powershell
docker compose up -d
```

**Verás:**
```
[+] Running 16/16
 ✔ Container rhinometric-postgres           Started
 ✔ Container rhinometric-redis              Started
 ✔ Container rhinometric-license-server     Started
 ✔ Container rhinometric-prometheus         Started
 ✔ Container rhinometric-loki               Started
 ✔ Container rhinometric-tempo              Started
 ✔ Container rhinometric-telemetrygen       Started
 ✔ Container rhinometric-grafana            Started
 ✔ Container rhinometric-alertmanager       Started
 ✔ Container rhinometric-node-exporter      Started
 ✔ Container rhinometric-cadvisor           Started
 ✔ Container rhinometric-blackbox-exporter  Started
 ✔ Container rhinometric-postgres-exporter  Started
 ✔ Container rhinometric-license-dashboard  Started
 ✔ Container rhinometric-nginx              Started
 ✔ Container rhinometric-promtail           Started
```

⏳ **Espera 30-60 segundos** para que todos los servicios estén listos.

### Paso 4: Verificar Instalación

```powershell
docker ps
```

Deberías ver 16 contenedores con estado **"Up"**.

**Alternativa:** Usar script de validación:
```powershell
bash validate.sh
```

### Paso 5: Abrir Grafana

1. Abre tu navegador (Chrome, Edge, Firefox)
2. Ve a: **http://localhost:3000**
3. Login:
   - **Usuario:** `admin`
   - **Contraseña:** `admin_secure_2024`

🎉 **¡Listo!** Explora los 7 dashboards precargados.

---

## 🛑 Detener Rhinometric

```powershell
docker compose down
```

---

## 🔄 Reiniciar Rhinometric

```powershell
docker compose restart
```

---

## 🔧 Troubleshooting

### ❌ Error "Docker daemon is not running"

**Solución:**
1. Abre Docker Desktop desde el menú Inicio
2. Espera a que el ícono en la barra de tareas muestre "Docker Desktop is running"
3. Intenta de nuevo

### ❌ Error "port 3000 is already allocated"

**Solución:** Otro servicio está usando el puerto 3000.

```powershell
# Ver qué proceso usa el puerto
netstat -ano | findstr :3000

# Detener el proceso (usa el PID del comando anterior)
taskkill /PID <numero_pid> /F

# O cambiar el puerto en docker-compose.yml:
# grafana:
#   ports:
#     - "3001:3000"
```

### ❌ Error "permission denied"

**Solución:**
1. Ejecuta PowerShell como Administrador
2. Clic derecho en PowerShell → "Ejecutar como administrador"

### ❌ Grafana no carga

```powershell
# Ver logs de Grafana
docker logs rhinometric-grafana

# Si hay errores, reiniciar:
docker restart rhinometric-grafana

# Esperar 30 segundos y abrir http://localhost:3000
```

### ❌ RAM insuficiente

**Solución:**
1. Abrir Docker Desktop
2. Settings → Resources → Memory
3. Aumentar a mínimo **8 GB**
4. Clic "Apply & Restart"

---

## 📞 Soporte

Si los problemas persisten:

```powershell
# Guardar logs para enviar a soporte
docker compose logs > rhinometric-logs.txt
```

Envía el archivo `rhinometric-logs.txt` a: support@rhinometric.com

---

**Versión:** 1.0.0-production | **OS:** Windows 10/11
