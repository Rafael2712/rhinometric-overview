#!/bin/bash
echo "� Validando instalación Rhinometric..."
echo ""

CONTAINERS=(
    "rhinometric-grafana"
    "rhinometric-prometheus"
    "rhinometric-loki"
    "rhinometric-tempo"
    "rhinometric-postgres"
    "rhinometric-redis"
    "rhinometric-alertmanager"
    "rhinometric-nginx"
    "rhinometric-promtail"
    "rhinometric-node-exporter"
    "rhinometric-cadvisor"
    "rhinometric-blackbox-exporter"
    "rhinometric-postgres-exporter"
    "rhinometric-telemetrygen"
    "rhinometric-license-server"
    "rhinometric-license-dashboard"
)

RUNNING=0
TOTAL=16

for container in "${CONTAINERS[@]}"; do
    if docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        echo "✅ $container"
        ((RUNNING++))
    else
        echo "❌ $container (NO ESTÁ CORRIENDO)"
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  $RUNNING/$TOTAL contenedores UP"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ $RUNNING -eq $TOTAL ]; then
    echo "✅ ¡Todo funcionando correctamente!"
    exit 0
else
    echo "⚠️  Algunos contenedores no están corriendo"
    echo ""
    echo "Para ver logs:"
    echo "  docker logs <nombre_contenedor>"
    exit 1
fi
