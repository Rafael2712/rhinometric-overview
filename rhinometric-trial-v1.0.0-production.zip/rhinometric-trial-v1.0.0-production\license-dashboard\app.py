#!/usr/bin/env python3
"""
Rhinometric License Dashboard
Dashboard web para monitorizar todas las licencias en uso
"""

from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import sqlite3
from datetime import datetime, timedelta
import json
from typing import List, Dict, Any
import os

app = Flask(__name__)
CORS(app)

# Configuración
DB_PATH = os.getenv('LICENSE_DB_PATH', '/data/licenses.db')
DASHBOARD_PORT = int(os.getenv('DASHBOARD_PORT', 8080))
SECRET_KEY = os.getenv('DASHBOARD_SECRET', 'rhinometric-dashboard-secret-2024')

app.config['SECRET_KEY'] = SECRET_KEY


class LicenseMonitor:
    """Monitor de licencias"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
    
    def get_connection(self):
        """Obtener conexión a la base de datos"""
        return sqlite3.connect(self.db_path)
    
    def get_all_licenses(self) -> List[Dict[str, Any]]:
        """Obtener todas las licencias"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                id,
                client_name,
                client_id,
                license_type,
                hardware_id,
                created_at,
                expires_at,
                last_check,
                status
            FROM licenses
            ORDER BY created_at DESC
        """)
        
        licenses = []
        for row in cursor.fetchall():
            license_dict = dict(row)
            
            # Calcular días restantes
            if license_dict['expires_at']:
                expires = datetime.fromisoformat(license_dict['expires_at'])
                now = datetime.now()
                days_remaining = (expires - now).days
                license_dict['days_remaining'] = days_remaining
                license_dict['is_expired'] = days_remaining < 0
                license_dict['is_expiring_soon'] = 0 <= days_remaining <= 30
            else:
                license_dict['days_remaining'] = None
                license_dict['is_expired'] = False
                license_dict['is_expiring_soon'] = False
            
            # Calcular tiempo desde último check
            if license_dict['last_check']:
                last_check = datetime.fromisoformat(license_dict['last_check'])
                hours_since_check = (datetime.now() - last_check).total_seconds() / 3600
                license_dict['hours_since_check'] = round(hours_since_check, 1)
                license_dict['is_active'] = hours_since_check < 24  # Activa si check en últimas 24h
            else:
                license_dict['hours_since_check'] = None
                license_dict['is_active'] = False
            
            licenses.append(license_dict)
        
        conn.close()
        return licenses
    
    def get_statistics(self) -> Dict[str, Any]:
        """Obtener estadísticas generales"""
        licenses = self.get_all_licenses()
        
        stats = {
            'total': len(licenses),
            'active': sum(1 for lic in licenses if lic['is_active']),
            'expired': sum(1 for lic in licenses if lic['is_expired']),
            'expiring_soon': sum(1 for lic in licenses if lic['is_expiring_soon']),
            'trial': sum(1 for lic in licenses if lic['license_type'] == 'trial'),
            'annual': sum(1 for lic in licenses if lic['license_type'] == 'annual'),
            'permanent': sum(1 for lic in licenses if lic['license_type'] == 'permanent'),
        }
        
        # Licencias más activas (últimos checks)
        active_licenses = sorted(
            [lic for lic in licenses if lic['last_check']],
            key=lambda x: x['last_check'],
            reverse=True
        )[:5]
        
        stats['most_active'] = active_licenses
        
        # Licencias próximas a expirar
        expiring_licenses = sorted(
            [lic for lic in licenses if lic['is_expiring_soon']],
            key=lambda x: x['days_remaining']
        )[:5]
        
        stats['expiring_soon_list'] = expiring_licenses
        
        return stats
    
    def get_license_details(self, license_id: str) -> Dict[str, Any]:
        """Obtener detalles de una licencia específica"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM licenses WHERE id = ? OR client_id = ?
        """, (license_id, license_id))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return dict(row)
        return None
    
    def get_usage_history(self, days: int = 30) -> List[Dict[str, Any]]:
        """Obtener historial de uso de licencias"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        since_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute("""
            SELECT 
                DATE(last_check) as date,
                COUNT(DISTINCT client_id) as active_licenses
            FROM licenses
            WHERE last_check >= ?
            GROUP BY DATE(last_check)
            ORDER BY date
        """, (since_date,))
        
        history = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return history


# Instancia del monitor
monitor = LicenseMonitor(DB_PATH)


# =================================
# RUTAS API
# =================================

@app.route('/')
def index():
    """Página principal del dashboard"""
    return render_template('index.html')


@app.route('/api/licenses')
def api_licenses():
    """API: Obtener todas las licencias"""
    try:
        licenses = monitor.get_all_licenses()
        return jsonify({
            'success': True,
            'count': len(licenses),
            'licenses': licenses
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/statistics')
def api_statistics():
    """API: Obtener estadísticas"""
    try:
        stats = monitor.get_statistics()
        return jsonify({
            'success': True,
            'statistics': stats
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/license/<license_id>')
def api_license_details(license_id):
    """API: Obtener detalles de una licencia"""
    try:
        details = monitor.get_license_details(license_id)
        if details:
            return jsonify({
                'success': True,
                'license': details
            })
        else:
            return jsonify({
                'success': False,
                'error': 'License not found'
            }), 404
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/usage-history')
def api_usage_history():
    """API: Obtener historial de uso"""
    try:
        days = request.args.get('days', default=30, type=int)
        history = monitor.get_usage_history(days)
        return jsonify({
            'success': True,
            'history': history
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/health')
def health():
    """Health check"""
    return jsonify({
        'status': 'healthy',
        'service': 'rhinometric-license-dashboard',
        'timestamp': datetime.now().isoformat()
    })


# =================================
# INICIO DE LA APLICACIÓN
# =================================

if __name__ == '__main__':
    print(f"""
    ╔════════════════════════════════════════════════╗
    ║  Rhinometric License Dashboard                 ║
    ║  Monitoreo de Licencias en Tiempo Real        ║
    ╚════════════════════════════════════════════════╝
    
    🚀 Dashboard corriendo en: http://0.0.0.0:{DASHBOARD_PORT}
    📊 API disponible en: http://0.0.0.0:{DASHBOARD_PORT}/api
    🔑 Base de datos: {DB_PATH}
    
    """)
    
    app.run(
        host='0.0.0.0',
        port=DASHBOARD_PORT,
        debug=os.getenv('DEBUG', 'false').lower() == 'true'
    )
