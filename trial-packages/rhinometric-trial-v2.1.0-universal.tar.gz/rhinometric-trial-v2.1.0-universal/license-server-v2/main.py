#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════
 RHINOMETRIC LICENSE SERVER v2.1.0 - FASTAPI EDITION
═══════════════════════════════════════════════════════════════════════════

Rewritten from Flask to FastAPI for:
- Async/await support
- Better performance
- Automatic OpenAPI docs
- Type safety with Pydantic
- Production-ready features

Endpoints:
  GET  /api/health          - Health check
  GET  /api/metrics         - Prometheus metrics
  GET  /api/licenses        - List all licenses
  POST /api/licenses        - Create license
  GET  /api/licenses/{id}   - Get license details
  GET  /api/external-apis   - List configured APIs
  POST /api/external-apis   - Add new API connection

═══════════════════════════════════════════════════════════════════════════
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, timedelta
from prometheus_fastapi_instrumentator import Instrumentator
import asyncpg
import redis.asyncio as aioredis
import httpx
import os

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://rhinometric:rhinometric@postgres:5432/rhinometric_trial"
)
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")

# ═══════════════════════════════════════════════════════════════════════════
# PYDANTIC MODELS
# ═══════════════════════════════════════════════════════════════════════════

class HealthResponse(BaseModel):
    status: str
    version: str
    service: str
    timestamp: datetime
    database: str
    redis: str

class License(BaseModel):
    id: Optional[int] = None
    customer_name: str = Field(..., min_length=1, max_length=255)
    license_key: str = Field(..., min_length=10)
    created_at: Optional[datetime] = None
    expires_at: datetime
    is_active: bool = True

class ExternalAPI(BaseModel):
    id: Optional[int] = None
    name: str = Field(..., min_length=1, max_length=100)
    endpoint: str = Field(..., min_length=10)
    auth_type: Optional[str] = "none"
    auth_token: Optional[str] = None
    scrape_interval: int = Field(default=60, ge=10, le=3600)
    is_active: bool = True
    created_at: Optional[datetime] = None

# ═══════════════════════════════════════════════════════════════════════════
# FASTAPI APP
# ═══════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="Rhinometric License Server",
    description="FastAPI-based license management and API connector for Rhinometric v2.1.0",
    version="2.1.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Prometheus instrumentation
Instrumentator().instrument(app).expose(app, endpoint="/api/metrics")

# ═══════════════════════════════════════════════════════════════════════════
# DATABASE CONNECTION
# ═══════════════════════════════════════════════════════════════════════════

db_pool: Optional[asyncpg.Pool] = None
redis_client: Optional[aioredis.Redis] = None

@app.on_event("startup")
async def startup():
    global db_pool, redis_client
    
    # Connect to PostgreSQL
    try:
        db_pool = await asyncpg.create_pool(
            DATABASE_URL,
            min_size=5,
            max_size=20,
            command_timeout=10
        )
        print("✓ Connected to PostgreSQL")
    except Exception as e:
        print(f"✗ PostgreSQL connection failed: {e}")
        db_pool = None
    
    # Connect to Redis
    try:
        redis_client = aioredis.from_url(REDIS_URL, decode_responses=True)
        await redis_client.ping()
        print("✓ Connected to Redis")
    except Exception as e:
        print(f"⚠ Redis connection failed: {e}")
        redis_client = None

@app.on_event("shutdown")
async def shutdown():
    if db_pool:
        await db_pool.close()
    if redis_client:
        await redis_client.close()

# ═══════════════════════════════════════════════════════════════════════════
# DEPENDENCIES
# ═══════════════════════════════════════════════════════════════════════════

async def get_db():
    if not db_pool:
        raise HTTPException(status_code=503, detail="Database not available")
    async with db_pool.acquire() as connection:
        yield connection

# ═══════════════════════════════════════════════════════════════════════════
# HEALTH CHECK
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/api/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint for monitoring"""
    
    # Check database
    db_status = "connected"
    try:
        if db_pool:
            async with db_pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
        else:
            db_status = "disconnected"
    except Exception:
        db_status = "error"
    
    # Check Redis
    redis_status = "connected"
    try:
        if redis_client:
            await redis_client.ping()
        else:
            redis_status = "disconnected"
    except Exception:
        redis_status = "error"
    
    return HealthResponse(
        status="healthy",
        version="2.1.0",
        service="license-server",
        timestamp=datetime.utcnow(),
        database=db_status,
        redis=redis_status
    )

# ═══════════════════════════════════════════════════════════════════════════
# LICENSE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/api/licenses", response_model=List[License])
async def list_licenses(conn = Depends(get_db)):
    """List all licenses"""
    
    rows = await conn.fetch("""
        SELECT id, customer_name, license_key, created_at, expires_at, is_active
        FROM licenses
        ORDER BY created_at DESC
    """)
    
    return [License(**dict(row)) for row in rows]

@app.post("/api/licenses", response_model=License, status_code=201)
async def create_license(license: License, conn = Depends(get_db)):
    """Create a new license"""
    
    row = await conn.fetchrow("""
        INSERT INTO licenses (customer_name, license_key, expires_at, is_active)
        VALUES ($1, $2, $3, $4)
        RETURNING id, customer_name, license_key, created_at, expires_at, is_active
    """, license.customer_name, license.license_key, license.expires_at, license.is_active)
    
    return License(**dict(row))

@app.get("/api/licenses/{license_id}", response_model=License)
async def get_license(license_id: int, conn = Depends(get_db)):
    """Get license details"""
    
    row = await conn.fetchrow("""
        SELECT id, customer_name, license_key, created_at, expires_at, is_active
        FROM licenses
        WHERE id = $1
    """, license_id)
    
    if not row:
        raise HTTPException(status_code=404, detail="License not found")
    
    return License(**dict(row))

# ═══════════════════════════════════════════════════════════════════════════
# EXTERNAL API MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/api/external-apis", response_model=List[ExternalAPI])
async def list_external_apis(conn = Depends(get_db)):
    """List all configured external APIs"""
    
    rows = await conn.fetch("""
        SELECT id, name, endpoint, auth_type, auth_token, scrape_interval, is_active, created_at
        FROM external_apis
        ORDER BY created_at DESC
    """)
    
    return [ExternalAPI(**dict(row)) for row in rows]

@app.post("/api/external-apis", response_model=ExternalAPI, status_code=201)
async def create_external_api(api: ExternalAPI, conn = Depends(get_db)):
    """Add new external API connection"""
    
    # Test connectivity
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(api.endpoint)
            if response.status_code >= 400:
                raise HTTPException(
                    status_code=400,
                    detail=f"API returned status {response.status_code}"
                )
    except httpx.RequestError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot connect to API: {str(e)}"
        )
    
    # Save to database
    row = await conn.fetchrow("""
        INSERT INTO external_apis (name, endpoint, auth_type, auth_token, scrape_interval, is_active)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING id, name, endpoint, auth_type, auth_token, scrape_interval, is_active, created_at
    """, api.name, api.endpoint, api.auth_type, api.auth_token, api.scrape_interval, api.is_active)
    
    # Notify API proxy to reload config
    if redis_client:
        await redis_client.publish("api_config_reload", api.name)
    
    return ExternalAPI(**dict(row))

@app.delete("/api/external-apis/{api_id}", status_code=204)
async def delete_external_api(api_id: int, conn = Depends(get_db)):
    """Delete external API connection"""
    
    result = await conn.execute("DELETE FROM external_apis WHERE id = $1", api_id)
    
    if result == "DELETE 0":
        raise HTTPException(status_code=404, detail="API not found")
    
    return None

# ═══════════════════════════════════════════════════════════════════════════
# ROOT
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/")
async def root():
    return {
        "service": "Rhinometric License Server",
        "version": "2.1.0",
        "docs": "/api/docs",
        "health": "/api/health"
    }
