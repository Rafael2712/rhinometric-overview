from flask import Flask, request, jsonify
import jwt
import sqlite3
from datetime import datetime, timedelta
import uuid
import os

app = Flask(__name__)

# Configuración desde variables de entorno
SECRET_KEY = os.environ.get('JWT_SECRET', 'rhinometric-trial-secret-change-this')
DB_PATH = "/data/licenses.db"

def init_db():
    """Inicializar base de datos SQLite para licencias"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS licenses
                 (id TEXT PRIMARY KEY,
                  client_name TEXT,
                  client_id TEXT UNIQUE,
                  license_type TEXT,
                  hardware_id TEXT,
                  created_at TIMESTAMP,
                  expires_at TIMESTAMP,
                  last_check TIMESTAMP,
                  status TEXT)''')
    conn.commit()
    conn.close()
    print(f"✅ Base de datos inicializada en {DB_PATH}")

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "OK", "service": "rhinometric-license-server"})

@app.route('/generate', methods=['POST'])
def generate_license():
    """Generar nueva licencia"""
    data = request.json
    client_name = data.get('client_name')
    license_type = data.get('type', 'trial')
    hardware_id = data.get('hardware_id', 'demo-hardware-id')

    if not client_name:
        return jsonify({"error": "Missing client_name"}), 400

    # Calcular expiración
    days = 180 if license_type == 'trial' else 365 if license_type == 'annual' else 36500
    expires_at = datetime.now() + timedelta(days=days)

    # Crear payload JWT
    payload = {
        'client_name': client_name,
        'license_type': license_type,
        'hardware_id': hardware_id,
        'exp': expires_at.timestamp()
    }

    # Generar token JWT
    license_key = jwt.encode(payload, SECRET_KEY, algorithm='HS256')

    # Guardar en base de datos
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("""INSERT INTO licenses 
                     (id, client_name, client_id, license_type, hardware_id, 
                      created_at, expires_at, last_check, status) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (uuid.uuid4().hex, client_name, uuid.uuid4().hex, license_type, 
                   hardware_id, datetime.now(), expires_at, datetime.now(), 'active'))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({"error": "License already exists"}), 409
    conn.close()

    return jsonify({
        "license_key": license_key, 
        "expires": expires_at.isoformat(),
        "client_name": client_name,
        "type": license_type
    })

@app.route('/validate', methods=['POST'])
def validate_license():
    """Validar licencia existente"""
    data = request.json
    license_key = data.get('license_key')
    hardware_id = data.get('hardware_id')

    if not license_key:
        return jsonify({"error": "Missing license_key"}), 400

    try:
        # Decodificar JWT
        payload = jwt.decode(license_key, SECRET_KEY, algorithms=['HS256'])
        
        # Verificar hardware ID si se proporciona
        if hardware_id and payload.get('hardware_id') != hardware_id:
            return jsonify({"error": "Hardware ID mismatch"}), 401
        
        # Verificar expiración
        if payload['exp'] < datetime.now().timestamp():
            return jsonify({"error": "License expired"}), 403
        
        # Actualizar last_check
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("UPDATE licenses SET last_check = ? WHERE hardware_id = ?", 
                  (datetime.now(), payload.get('hardware_id')))
        conn.commit()
        conn.close()
        
        return jsonify({
            "status": "valid", 
            "expires": datetime.fromtimestamp(payload['exp']).isoformat(),
            "client_name": payload.get('client_name'),
            "license_type": payload.get('license_type')
        })
        
    except jwt.ExpiredSignatureError:
        return jsonify({"error": "License expired"}), 403
    except jwt.InvalidTokenError:
        return jsonify({"error": "Invalid license"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/webhooks/alerts', methods=['POST'])
@app.route('/api/webhooks/alerts/<severity>', methods=['POST'])
def webhook_alerts(severity='default'):
    """Webhook para recibir alertas de Alertmanager"""
    data = request.json
    print(f"📬 Alert received [{severity}]: {data}")
    return jsonify({"status": "received"}), 200

if __name__ == '__main__':
    init_db()
    print("🚀 Rhinometric License Server starting...")
    print(f"📁 Database: {DB_PATH}")
    app.run(host='0.0.0.0', port=5000, debug=False)
